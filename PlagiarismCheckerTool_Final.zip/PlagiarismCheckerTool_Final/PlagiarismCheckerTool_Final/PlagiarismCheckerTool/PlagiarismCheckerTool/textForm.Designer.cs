﻿namespace PlagiarismCheckerTool
{
    partial class textForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(textForm));
			this.bunifuThinButton21 = new Bunifu.Framework.UI.BunifuThinButton2();
			this.bunifuThinButton22 = new Bunifu.Framework.UI.BunifuThinButton2();
			this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
			this.fileATextbox1 = new Bunifu.Framework.UI.BunifuMetroTextbox();
			this.fileATextbox2 = new Bunifu.Framework.UI.BunifuMetroTextbox();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.fileBTextbox1 = new Bunifu.Framework.UI.BunifuMetroTextbox();
			this.fileBTextbox2 = new Bunifu.Framework.UI.BunifuMetroTextbox();
			this.searchButton2 = new Bunifu.Framework.UI.BunifuThinButton2();
			this.fileArichBox1 = new System.Windows.Forms.RichTextBox();
			this.fileBrichBox1 = new System.Windows.Forms.RichTextBox();
			((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
			this.SuspendLayout();
			// 
			// bunifuThinButton21
			// 
			this.bunifuThinButton21.ActiveBorderThickness = 1;
			this.bunifuThinButton21.ActiveCornerRadius = 20;
			this.bunifuThinButton21.ActiveFillColor = System.Drawing.Color.SeaGreen;
			this.bunifuThinButton21.ActiveForecolor = System.Drawing.Color.White;
			this.bunifuThinButton21.ActiveLineColor = System.Drawing.Color.SeaGreen;
			this.bunifuThinButton21.BackColor = System.Drawing.SystemColors.Control;
			this.bunifuThinButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton21.BackgroundImage")));
			this.bunifuThinButton21.ButtonText = "Add text file \'A\'";
			this.bunifuThinButton21.Cursor = System.Windows.Forms.Cursors.Hand;
			this.bunifuThinButton21.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
			this.bunifuThinButton21.ForeColor = System.Drawing.Color.SeaGreen;
			this.bunifuThinButton21.IdleBorderThickness = 1;
			this.bunifuThinButton21.IdleCornerRadius = 20;
			this.bunifuThinButton21.IdleFillColor = System.Drawing.Color.White;
			this.bunifuThinButton21.IdleForecolor = System.Drawing.Color.SeaGreen;
			this.bunifuThinButton21.IdleLineColor = System.Drawing.Color.SeaGreen;
			this.bunifuThinButton21.Location = new System.Drawing.Point(46, 78);
			this.bunifuThinButton21.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
			this.bunifuThinButton21.Name = "bunifuThinButton21";
			this.bunifuThinButton21.Size = new System.Drawing.Size(255, 52);
			this.bunifuThinButton21.TabIndex = 2;
			this.bunifuThinButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.bunifuThinButton21.Click += new System.EventHandler(this.bunifuThinButton21_Click);
			// 
			// bunifuThinButton22
			// 
			this.bunifuThinButton22.ActiveBorderThickness = 1;
			this.bunifuThinButton22.ActiveCornerRadius = 20;
			this.bunifuThinButton22.ActiveFillColor = System.Drawing.Color.SeaGreen;
			this.bunifuThinButton22.ActiveForecolor = System.Drawing.Color.White;
			this.bunifuThinButton22.ActiveLineColor = System.Drawing.Color.SeaGreen;
			this.bunifuThinButton22.BackColor = System.Drawing.SystemColors.Control;
			this.bunifuThinButton22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton22.BackgroundImage")));
			this.bunifuThinButton22.ButtonText = "Add text file \'B\'";
			this.bunifuThinButton22.Cursor = System.Windows.Forms.Cursors.Hand;
			this.bunifuThinButton22.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
			this.bunifuThinButton22.ForeColor = System.Drawing.Color.SeaGreen;
			this.bunifuThinButton22.IdleBorderThickness = 1;
			this.bunifuThinButton22.IdleCornerRadius = 20;
			this.bunifuThinButton22.IdleFillColor = System.Drawing.Color.White;
			this.bunifuThinButton22.IdleForecolor = System.Drawing.Color.SeaGreen;
			this.bunifuThinButton22.IdleLineColor = System.Drawing.Color.SeaGreen;
			this.bunifuThinButton22.Location = new System.Drawing.Point(374, 78);
			this.bunifuThinButton22.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
			this.bunifuThinButton22.Name = "bunifuThinButton22";
			this.bunifuThinButton22.Size = new System.Drawing.Size(255, 52);
			this.bunifuThinButton22.TabIndex = 3;
			this.bunifuThinButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.bunifuThinButton22.Click += new System.EventHandler(this.bunifuThinButton22_Click);
			// 
			// bunifuImageButton1
			// 
			this.bunifuImageButton1.BackColor = System.Drawing.Color.SeaGreen;
			this.bunifuImageButton1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.ErrorImage")));
			this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
			this.bunifuImageButton1.ImageActive = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.ImageActive")));
			this.bunifuImageButton1.Location = new System.Drawing.Point(12, 12);
			this.bunifuImageButton1.Name = "bunifuImageButton1";
			this.bunifuImageButton1.Size = new System.Drawing.Size(88, 57);
			this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.bunifuImageButton1.TabIndex = 4;
			this.bunifuImageButton1.TabStop = false;
			this.bunifuImageButton1.Zoom = 10;
			this.bunifuImageButton1.Click += new System.EventHandler(this.bunifuImageButton1_Click);
			// 
			// fileATextbox1
			// 
			this.fileATextbox1.BorderColorFocused = System.Drawing.Color.Blue;
			this.fileATextbox1.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.fileATextbox1.BorderColorMouseHover = System.Drawing.Color.Blue;
			this.fileATextbox1.BorderThickness = 3;
			this.fileATextbox1.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.fileATextbox1.Font = new System.Drawing.Font("Century Gothic", 9.75F);
			this.fileATextbox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.fileATextbox1.isPassword = false;
			this.fileATextbox1.Location = new System.Drawing.Point(46, 132);
			this.fileATextbox1.Margin = new System.Windows.Forms.Padding(4);
			this.fileATextbox1.Name = "fileATextbox1";
			this.fileATextbox1.Size = new System.Drawing.Size(255, 43);
			this.fileATextbox1.TabIndex = 6;
			this.fileATextbox1.Text = "*Path of file";
			this.fileATextbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.fileATextbox1.OnValueChanged += new System.EventHandler(this.fileATextbox1_OnValueChanged);
			// 
			// fileATextbox2
			// 
			this.fileATextbox2.BorderColorFocused = System.Drawing.Color.Blue;
			this.fileATextbox2.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.fileATextbox2.BorderColorMouseHover = System.Drawing.Color.Blue;
			this.fileATextbox2.BorderThickness = 3;
			this.fileATextbox2.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.fileATextbox2.Font = new System.Drawing.Font("Century Gothic", 9.75F);
			this.fileATextbox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.fileATextbox2.isPassword = false;
			this.fileATextbox2.Location = new System.Drawing.Point(46, 187);
			this.fileATextbox2.Margin = new System.Windows.Forms.Padding(8);
			this.fileATextbox2.Name = "fileATextbox2";
			this.fileATextbox2.Size = new System.Drawing.Size(255, 36);
			this.fileATextbox2.TabIndex = 7;
			this.fileATextbox2.Text = "*File name";
			this.fileATextbox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.fileATextbox2.OnValueChanged += new System.EventHandler(this.fileATextbox2_OnValueChanged);
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.FileName = "openFileDialog1";
			// 
			// fileBTextbox1
			// 
			this.fileBTextbox1.BorderColorFocused = System.Drawing.Color.Blue;
			this.fileBTextbox1.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.fileBTextbox1.BorderColorMouseHover = System.Drawing.Color.Blue;
			this.fileBTextbox1.BorderThickness = 3;
			this.fileBTextbox1.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.fileBTextbox1.Font = new System.Drawing.Font("Century Gothic", 9.75F);
			this.fileBTextbox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.fileBTextbox1.isPassword = false;
			this.fileBTextbox1.Location = new System.Drawing.Point(374, 132);
			this.fileBTextbox1.Margin = new System.Windows.Forms.Padding(4);
			this.fileBTextbox1.Name = "fileBTextbox1";
			this.fileBTextbox1.Size = new System.Drawing.Size(255, 43);
			this.fileBTextbox1.TabIndex = 9;
			this.fileBTextbox1.Text = "*Path of file";
			this.fileBTextbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.fileBTextbox1.OnValueChanged += new System.EventHandler(this.fileBTextbox1_OnValueChanged);
			// 
			// fileBTextbox2
			// 
			this.fileBTextbox2.BorderColorFocused = System.Drawing.Color.Blue;
			this.fileBTextbox2.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.fileBTextbox2.BorderColorMouseHover = System.Drawing.Color.Blue;
			this.fileBTextbox2.BorderThickness = 3;
			this.fileBTextbox2.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.fileBTextbox2.Font = new System.Drawing.Font("Century Gothic", 9.75F);
			this.fileBTextbox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.fileBTextbox2.isPassword = false;
			this.fileBTextbox2.Location = new System.Drawing.Point(374, 187);
			this.fileBTextbox2.Margin = new System.Windows.Forms.Padding(8);
			this.fileBTextbox2.Name = "fileBTextbox2";
			this.fileBTextbox2.Size = new System.Drawing.Size(255, 36);
			this.fileBTextbox2.TabIndex = 10;
			this.fileBTextbox2.Text = "*File name";
			this.fileBTextbox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			// 
			// searchButton2
			// 
			this.searchButton2.ActiveBorderThickness = 1;
			this.searchButton2.ActiveCornerRadius = 20;
			this.searchButton2.ActiveFillColor = System.Drawing.Color.SeaGreen;
			this.searchButton2.ActiveForecolor = System.Drawing.Color.White;
			this.searchButton2.ActiveLineColor = System.Drawing.Color.SeaGreen;
			this.searchButton2.BackColor = System.Drawing.SystemColors.Control;
			this.searchButton2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("searchButton2.BackgroundImage")));
			this.searchButton2.ButtonText = "Search !";
			this.searchButton2.Cursor = System.Windows.Forms.Cursors.Hand;
			this.searchButton2.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
			this.searchButton2.ForeColor = System.Drawing.Color.SeaGreen;
			this.searchButton2.IdleBorderThickness = 1;
			this.searchButton2.IdleCornerRadius = 20;
			this.searchButton2.IdleFillColor = System.Drawing.Color.White;
			this.searchButton2.IdleForecolor = System.Drawing.Color.SeaGreen;
			this.searchButton2.IdleLineColor = System.Drawing.Color.SeaGreen;
			this.searchButton2.Location = new System.Drawing.Point(213, 503);
			this.searchButton2.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
			this.searchButton2.Name = "searchButton2";
			this.searchButton2.Size = new System.Drawing.Size(255, 52);
			this.searchButton2.TabIndex = 12;
			this.searchButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.searchButton2.Click += new System.EventHandler(this.searchButton2_Click);
			// 
			// fileArichBox1
			// 
			this.fileArichBox1.Location = new System.Drawing.Point(46, 234);
			this.fileArichBox1.Name = "fileArichBox1";
			this.fileArichBox1.Size = new System.Drawing.Size(255, 251);
			this.fileArichBox1.TabIndex = 13;
			this.fileArichBox1.Text = "";
			// 
			// fileBrichBox1
			// 
			this.fileBrichBox1.Location = new System.Drawing.Point(389, 234);
			this.fileBrichBox1.Name = "fileBrichBox1";
			this.fileBrichBox1.Size = new System.Drawing.Size(249, 251);
			this.fileBrichBox1.TabIndex = 14;
			this.fileBrichBox1.Text = "";
			this.fileBrichBox1.TextChanged += new System.EventHandler(this.fileBrichBox1_TextChanged);
			// 
			// textForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(729, 749);
			this.Controls.Add(this.fileBrichBox1);
			this.Controls.Add(this.fileArichBox1);
			this.Controls.Add(this.searchButton2);
			this.Controls.Add(this.fileBTextbox2);
			this.Controls.Add(this.fileBTextbox1);
			this.Controls.Add(this.fileATextbox2);
			this.Controls.Add(this.fileATextbox1);
			this.Controls.Add(this.bunifuImageButton1);
			this.Controls.Add(this.bunifuThinButton22);
			this.Controls.Add(this.bunifuThinButton21);
			this.Name = "textForm";
			this.Text = "Text Files";
			this.Load += new System.EventHandler(this.textForm_Load);
			((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
			this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton21;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton22;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private Bunifu.Framework.UI.BunifuMetroTextbox fileATextbox1;
        private Bunifu.Framework.UI.BunifuMetroTextbox fileATextbox2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private Bunifu.Framework.UI.BunifuMetroTextbox fileBTextbox1;
        private Bunifu.Framework.UI.BunifuMetroTextbox fileBTextbox2;
        private Bunifu.Framework.UI.BunifuThinButton2 searchButton2;
        private System.Windows.Forms.RichTextBox fileArichBox1;
        private System.Windows.Forms.RichTextBox fileBrichBox1;
    }
}