﻿namespace PlagiarismCheckerTool
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.textfilebutton = new Bunifu.Framework.UI.BunifuThinButton2();
            this.filefolderbutton = new Bunifu.Framework.UI.BunifuThinButton2();
            this.cppfilebutton = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuMetroTextbox1 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.SuspendLayout();
            // 
            // textfilebutton
            // 
            this.textfilebutton.ActiveBorderThickness = 1;
            this.textfilebutton.ActiveCornerRadius = 20;
            this.textfilebutton.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.textfilebutton.ActiveForecolor = System.Drawing.Color.White;
            this.textfilebutton.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.textfilebutton.BackColor = System.Drawing.SystemColors.Control;
            this.textfilebutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("textfilebutton.BackgroundImage")));
            this.textfilebutton.ButtonText = "Text Files";
            this.textfilebutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textfilebutton.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.textfilebutton.ForeColor = System.Drawing.Color.SeaGreen;
            this.textfilebutton.IdleBorderThickness = 1;
            this.textfilebutton.IdleCornerRadius = 20;
            this.textfilebutton.IdleFillColor = System.Drawing.Color.White;
            this.textfilebutton.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.textfilebutton.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.textfilebutton.Location = new System.Drawing.Point(13, 175);
            this.textfilebutton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textfilebutton.Name = "textfilebutton";
            this.textfilebutton.Size = new System.Drawing.Size(189, 59);
            this.textfilebutton.TabIndex = 0;
            this.textfilebutton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.textfilebutton.Click += new System.EventHandler(this.textfilebutton_Click);
            // 
            // filefolderbutton
            // 
            this.filefolderbutton.ActiveBorderThickness = 1;
            this.filefolderbutton.ActiveCornerRadius = 20;
            this.filefolderbutton.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.filefolderbutton.ActiveForecolor = System.Drawing.Color.White;
            this.filefolderbutton.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.filefolderbutton.BackColor = System.Drawing.SystemColors.Control;
            this.filefolderbutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("filefolderbutton.BackgroundImage")));
            this.filefolderbutton.ButtonText = "Files/Folders";
            this.filefolderbutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.filefolderbutton.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.filefolderbutton.ForeColor = System.Drawing.Color.SeaGreen;
            this.filefolderbutton.IdleBorderThickness = 1;
            this.filefolderbutton.IdleCornerRadius = 20;
            this.filefolderbutton.IdleFillColor = System.Drawing.Color.White;
            this.filefolderbutton.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.filefolderbutton.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.filefolderbutton.Location = new System.Drawing.Point(228, 175);
            this.filefolderbutton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.filefolderbutton.Name = "filefolderbutton";
            this.filefolderbutton.Size = new System.Drawing.Size(189, 59);
            this.filefolderbutton.TabIndex = 1;
            this.filefolderbutton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.filefolderbutton.Click += new System.EventHandler(this.filefolderbutton_Click);
            // 
            // cppfilebutton
            // 
            this.cppfilebutton.ActiveBorderThickness = 1;
            this.cppfilebutton.ActiveCornerRadius = 20;
            this.cppfilebutton.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.cppfilebutton.ActiveForecolor = System.Drawing.Color.White;
            this.cppfilebutton.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.cppfilebutton.BackColor = System.Drawing.SystemColors.Control;
            this.cppfilebutton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cppfilebutton.BackgroundImage")));
            this.cppfilebutton.ButtonText = "C++ Files";
            this.cppfilebutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cppfilebutton.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.cppfilebutton.ForeColor = System.Drawing.Color.SeaGreen;
            this.cppfilebutton.IdleBorderThickness = 1;
            this.cppfilebutton.IdleCornerRadius = 20;
            this.cppfilebutton.IdleFillColor = System.Drawing.Color.White;
            this.cppfilebutton.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.cppfilebutton.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.cppfilebutton.Location = new System.Drawing.Point(447, 175);
            this.cppfilebutton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cppfilebutton.Name = "cppfilebutton";
            this.cppfilebutton.Size = new System.Drawing.Size(189, 59);
            this.cppfilebutton.TabIndex = 2;
            this.cppfilebutton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cppfilebutton.Click += new System.EventHandler(this.bunifuThinButton23_Click);
            // 
            // bunifuMetroTextbox1
            // 
            this.bunifuMetroTextbox1.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMetroTextbox1.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMetroTextbox1.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMetroTextbox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bunifuMetroTextbox1.BorderThickness = 3;
            this.bunifuMetroTextbox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMetroTextbox1.Enabled = false;
            this.bunifuMetroTextbox1.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuMetroTextbox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMetroTextbox1.isPassword = false;
            this.bunifuMetroTextbox1.Location = new System.Drawing.Point(55, 93);
            this.bunifuMetroTextbox1.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.bunifuMetroTextbox1.Name = "bunifuMetroTextbox1";
            this.bunifuMetroTextbox1.Size = new System.Drawing.Size(557, 68);
            this.bunifuMetroTextbox1.TabIndex = 3;
            this.bunifuMetroTextbox1.Text = "Chose an option for Plagiarism";
            this.bunifuMetroTextbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(671, 356);
            this.Controls.Add(this.bunifuMetroTextbox1);
            this.Controls.Add(this.cppfilebutton);
            this.Controls.Add(this.filefolderbutton);
            this.Controls.Add(this.textfilebutton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuThinButton2 textfilebutton;
        private Bunifu.Framework.UI.BunifuThinButton2 filefolderbutton;
        private Bunifu.Framework.UI.BunifuThinButton2 cppfilebutton;
        private Bunifu.Framework.UI.BunifuMetroTextbox bunifuMetroTextbox1;
    }
}

