﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;

namespace PlagiarismCheckerTool
{
    public partial class fileForm : Form
    {
        public List<string> commonWords;
        public fileForm()
        {
            InitializeComponent();
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Hide();
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog FBD = new FolderBrowserDialog();
            if (FBD.ShowDialog() == DialogResult.OK)
            {
                listBox1.Items.Clear();
                string[] files = Directory.GetFiles(FBD.SelectedPath, "*.txt*");



                foreach (string file in files)
                {
                    listBox1.Items.Add(file);
                }


            }
        }
        public void check_Plagiarism()
        {

            string[] paths = new string[listBox1.Items.Count];
            listBox1.Items.CopyTo(paths, 0);

            Hashtable[] htableArray = new Hashtable[paths.Length];

            //initializing the hastable array


            for (int i = 0; i < htableArray.Length; i++)
            {
                htableArray[i] = new Hashtable();
            }


            if (paths.Count() > 1)
            {
                for (int i = 0; i < paths.Length; i++)
                {
                    string Str = File.ReadAllText(paths[i]);
                    string[] arr = FileWords(Str);

                    for (int j = 0; j < arr.Length; j++)
                    {
                        if (!htableArray[i].ContainsValue(arr[j]) && (!String.IsNullOrEmpty(arr[j])))
                        {
                            htableArray[i].Add(hashFunction(arr[j]), arr[j]);
                        }

                    }

                }



                int smallerHashIndex = 0;
                for (int i = 0; i < htableArray.Length; i++)
                {
                    if (htableArray[i].Count <= htableArray[smallerHashIndex].Count)
                    {
                        smallerHashIndex = i;

                    }
                }

                commonWords = new List<string>();//htableArray[smallerHashIndex].Values.Cast<string>().ToList();

                foreach (string word in htableArray[smallerHashIndex].Values)
                {
                    int count = 0;
                    for (int l = 0; l < htableArray.Length; l++)
                    {
                        if (htableArray[l].ContainsValue(word))
                        {
                            count++;
                        }
                    }

                    if (count == htableArray.Length)
                    {
                        commonWords.Add(word);
                    }

                }


                foreach (string s in commonWords)
                {
                    Console.WriteLine(s);
                }



            }
        }






        public string hashFunction(string word)
        {
            string key = "";
            for (int i = 0; i < word.Length; i++)
            {
                key += (int)word[i]; //converting to ascii
            }
            return key;
        }
        public string[] FileWords(string CompleteFile)
        {
            string str = CompleteFile.Replace("\r", "").Replace("\n", " ").Replace("\r\n", " ");             //replacing new line charaters

            string[] array = str.Split(' ');             //splitting  file into words

            List<string> list = new List<string>();

            for (int i = 0; i < array.Length; i++)
            {
                if (String.IsNullOrEmpty(array[i]) || String.IsNullOrWhiteSpace(array[i]))
                {
                    continue;
                }
                else
                {
                    list.Add(array[i]);
                }
            }


            return list.ToArray();

        }






        private object Lengthof(string[] files)
        {
            throw new NotImplementedException();
        }

        private void fileForm_Load(object sender, EventArgs e)
        {

        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            check_Plagiarism();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //listBox1.ClearSelected();
        }

        private void bunifuCustomLabel1_Click(object sender, EventArgs e)
        {

        }
        OpenFileDialog ofd_S = new OpenFileDialog();
        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
            if (ofd_S.ShowDialog() == DialogResult.OK)
            {
                //fileATextbox1.Text = ofd_S.FileName;
                //fileATextbox2.Text = ofd_A.SafeFileName;

                SelectedrichTextBox1.Text = File.ReadAllText(ofd_S.FileName);
            }
        }




        private void bunifuThinButton24_Click(object sender, EventArgs e)
        {
            highlightSelectedFile(commonWords);
        }
        public void highlightSelectedFile(List<string> commonWords)
        {
            for (int i = 0; i < commonWords.Count; i++)
            {
                int start = 0;
                int last = SelectedrichTextBox1.Text.Length;

                string findWord = commonWords[i];

                MessageBox.Show("hello");
                while (start < last)
                {
                    int startIndex = SelectedrichTextBox1.Find(findWord, start, SelectedrichTextBox1.TextLength, RichTextBoxFinds.WholeWord);

                    if (startIndex != -1)
                    {
                        SelectedrichTextBox1.SelectionStart = startIndex;
                        SelectedrichTextBox1.SelectionLength = findWord.Length;
                        SelectedrichTextBox1.SelectionBackColor = Color.Yellow;

                    }
                    else
                    {
                        break;
                    }

                    start = startIndex + findWord.Length;


                }
            }
        }





    }
}




    


