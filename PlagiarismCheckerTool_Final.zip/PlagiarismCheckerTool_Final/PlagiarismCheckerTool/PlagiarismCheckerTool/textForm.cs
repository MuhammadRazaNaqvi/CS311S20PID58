﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;

namespace PlagiarismCheckerTool
{
    public partial class textForm : Form
    {
        public textForm()
        {
            InitializeComponent();
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Hide();
        }

        OpenFileDialog ofd_A = new OpenFileDialog();
        string line_A = ""; 

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            if (ofd_A.ShowDialog() == DialogResult.OK)
            {
                fileATextbox1.Text = ofd_A.FileName;
                fileATextbox2.Text = ofd_A.SafeFileName;

            fileArichBox1.Text =  File.ReadAllText(ofd_A.FileName);
            }
        }

        OpenFileDialog ofd_B = new OpenFileDialog();
        string line_B = "";


        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            if (ofd_B.ShowDialog() == DialogResult.OK)
            {
                fileBTextbox1.Text = ofd_B.FileName;
                fileBTextbox2.Text = ofd_B.SafeFileName;

                fileBrichBox1.Text = File.ReadAllText(ofd_B.FileName);
            }
        }

        private void fileAlistBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textForm_Load(object sender, EventArgs e)
        {
            ofd_A.Filter = "Text Files (.txt)| *.txt";
            ofd_B.Filter = "Text Files (.txt)| *.txt";

            // ofd.Filter = "Text Files (.doc)| *.doc";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void fileATextbox1_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void fileATextbox2_OnValueChanged(object sender, EventArgs e)
        {

        }

        public string[] FileWords(string CompleteFile)
        {
            string str = CompleteFile.Replace("\r", "").Replace("\n", " ").Replace("\r\n", " ");             //replacing new line charaters
           
            string[] array = str.Split(' ');             //splitting  file into words

            List<string> list = new List<string>();

            for (int i = 0; i < array.Length; i++)
            {
                if (String.IsNullOrEmpty(array[i]) || String.IsNullOrWhiteSpace(array[i]))
                {
                    continue;
                }
                else
                {
                    list.Add(array[i]);
                }
            }


            return list.ToArray();

        }



        //hash function that returns a KEY after converting into ASCII 
        public string hashFunction(string word)
        {
            string key = "";
            for(int i=0;i< word.Length;i++)
            {
                key += (int)word[i]; //converting to ascii
            }
            return key;
        }




        private void searchButton2_Click(object sender, EventArgs e)
        {

            fileArichBox1.Text = File.ReadAllText(fileATextbox1.Text);
            fileBrichBox1.Text = File.ReadAllText(fileBTextbox1.Text);

            string[] arrFileA = FileWords(fileArichBox1.Text);
            string[] arrFileB = FileWords(fileBrichBox1.Text);
            

            //  building hash tables for both files

            Hashtable htFileA = new Hashtable();
            Hashtable htFileB = new Hashtable();


            //This is for file A 
            for (int i = 0; i < arrFileA.Length; i++)
            {
                if (! htFileA.ContainsValue(arrFileA[i]) && (!String.IsNullOrEmpty(arrFileA[i])))
                {
                    htFileA.Add(hashFunction(arrFileA[i]),arrFileA[i]);
                }
               
            }


            //This is for file B
            for (int i = 0; i < arrFileB.Length; i++)
            {
                if (!htFileB.ContainsValue(arrFileB[i]) && (!String.IsNullOrEmpty(arrFileB[i])))
                {
                    htFileB.Add(hashFunction(arrFileB[i]), arrFileB[i]);
                }

            }

//==========================




          
           //choose smaller hash table
            int smallerHash=0;
            if(htFileA.Count<= htFileB.Count)
            {
                smallerHash = 1;
                
            }
            else
            {

                smallerHash = 2;
            }

            List<string> commonWords = new List<string>();

            if(smallerHash==1)
            {

                foreach (string str  in htFileA.Values )
                {
                   if( htFileB.ContainsValue(str))
                    {
                        commonWords.Add(str);
                    }
                }

            }else if(smallerHash == 2)
            {
                foreach (string str in htFileB.Values)
                {
                    if (htFileA.ContainsValue(str))
                    {
                        commonWords.Add(str);
                    }
                }



            }

            foreach (string s in commonWords)
            {
                Console.WriteLine(s);
            }

            //highlight common words
            highlightFileA(commonWords);

            highlightFileB(commonWords);
            
        }


       public void highlightFileA(List <string> commonWords )
        {
            for (int i = 0; i < commonWords.Count; i++)
            {
                int start = 0;
                int last = fileArichBox1.Text.Length;
                //   fileArichBox1.SelectAll();
                //    fileArichBox1.SelectionBackColor = Color.White;
                string findWord = commonWords[i];


                while (start < last)
                {
                    int startIndex = fileArichBox1.Find(findWord, start, fileArichBox1.TextLength, RichTextBoxFinds.WholeWord);

                    if (startIndex != -1)
                    {
                        fileArichBox1.SelectionStart = startIndex;
                        fileArichBox1.SelectionLength = findWord.Length;
                        fileArichBox1.SelectionBackColor = Color.Red;

                    }
                    else
                    {
                        break;
                    }

                    start = startIndex + findWord.Length;


                }
            }
        }



        public void highlightFileB(List<string> commonWords)
        {
            for (int i = 0; i < commonWords.Count; i++)
            {
                int start = 0;
                int last = fileBrichBox1.Text.Length;
                //   fileArichBox1.SelectAll();
                //    fileArichBox1.SelectionBackColor = Color.White;
                string findWord = commonWords[i];


                while (start < last)
                {


                    int startIndex = fileBrichBox1.Find(findWord, start, fileBrichBox1.TextLength, RichTextBoxFinds.WholeWord);


                    if (startIndex != -1)
                    {
                        fileBrichBox1.SelectionStart = startIndex;
                        fileBrichBox1.SelectionLength = findWord.Length;
                        fileBrichBox1.SelectionBackColor = Color.Red;

                    }
                    else
                    {
                        break;
                    }

                    start = startIndex + findWord.Length;


                }
            }
        }

		private void fileBrichBox1_TextChanged(object sender, EventArgs e)
		{

		}
	}
}
