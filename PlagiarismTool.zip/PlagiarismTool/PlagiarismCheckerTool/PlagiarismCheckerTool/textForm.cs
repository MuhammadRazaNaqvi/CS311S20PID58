﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace PlagiarismCheckerTool
{
    public partial class textForm : Form
    {
        public textForm()
        {
            InitializeComponent();
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Hide();
        }

        OpenFileDialog ofd_A = new OpenFileDialog();
        string line_A = ""; 

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            if (ofd_A.ShowDialog() == DialogResult.OK)
            {
                fileATextbox1.Text = ofd_A.FileName;
                fileATextbox2.Text = ofd_A.SafeFileName;

            fileArichBox1.Text =  File.ReadAllText(ofd_A.FileName);
            }
        }

        OpenFileDialog ofd_B = new OpenFileDialog();
        string line_B = "";


        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            if (ofd_B.ShowDialog() == DialogResult.OK)
            {
                fileBTextbox1.Text = ofd_B.FileName;
                fileBTextbox2.Text = ofd_B.SafeFileName;

                fileBrichBox1.Text = File.ReadAllText(ofd_B.FileName);
            }
        }

        private void fileAlistBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textForm_Load(object sender, EventArgs e)
        {
            ofd_A.Filter = "Text Files (.txt)| *.txt";
            ofd_B.Filter = "Text Files (.txt)| *.txt";

            // ofd.Filter = "Text Files (.doc)| *.doc";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void fileATextbox1_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void fileATextbox2_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void searchButton2_Click(object sender, EventArgs e)
        {   
            //hashtable ht = new hashtable



            int start = 0;
            int last = fileArichBox1.Text.Length;
            //   fileArichBox1.SelectAll();
            //    fileArichBox1.SelectionBackColor = Color.White;
            string findWord = "CHS" ;


            while(start < last)
            {


                int startIndex =  fileArichBox1.Find(findWord, start, fileArichBox1.TextLength, RichTextBoxFinds.MatchCase);
                
                
                if(startIndex != -1)
                {
                    fileArichBox1.SelectionStart = startIndex;
                    fileArichBox1.SelectionLength = findWord.Length;
                    fileArichBox1.SelectionBackColor = Color.Red;

                }
                else
                {
                    break;
                }

                start = startIndex + findWord.Length;


            }

        }
    }
}
